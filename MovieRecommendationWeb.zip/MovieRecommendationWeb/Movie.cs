namespace MovieRecommendationWeb.Models
{
    public class Movie
    {
        public string Title { get; set; }
        public string Genre { get; set; }
    }
}
